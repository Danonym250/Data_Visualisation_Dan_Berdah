# Data-Visu

Notre projet projet porte sur l'étude du prix de l'énergie (gaz et électricité) en Europe.

Vous pouvez visualiser les données via ce lien https://datavislsn.shinyapps.io/shinyapp/.

Si vous voulez les garder hors connexion, il faut télécharger le dossier DATA VIS en entier, en effet, tous les documents à part "Donnée de gaz par pays original" sont utilisés, le dossier www doit être laissé ainsi dans le dossier principal (format par défaut dans R).
Il convient d'éxcécuter chaque partie du code (server, ui) avant de lancer l'application pour éviter d'éventuelles erreurs.

